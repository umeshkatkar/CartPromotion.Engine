﻿using CartPromotion.Engine.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartPromotion.Engine
{
    public interface IProductPromotion
    {
        decimal GetPriceByType(string  type);
        decimal GetTotalPrice(List<Product> products);
    }
}
