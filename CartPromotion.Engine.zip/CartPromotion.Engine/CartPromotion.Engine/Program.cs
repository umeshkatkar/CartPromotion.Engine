﻿using CartPromotion.Engine.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartPromotion.Engine
{
    class Program
    {
        static void Main(string[] args)
        {
                   
            List<Product> lstProducts = new List<Product>();
            PrmotionService prmotionService = new PrmotionService();
            Console.WriteLine("Enter total number of orders");
            int orders = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i <orders; i++)
            {
                Console.WriteLine(" Select Product Type :A,B,C,D");
                string type = Console.ReadLine().ToUpper();
                if (!string.IsNullOrEmpty(type))
                {
                    Product product = new Product();
                    product.Type = type;
                    decimal price= prmotionService.GetPriceByType(type);
                    if (price > 0)
                    {
                        lstProducts.Add(product);
                    }
                }
                                
            }
            if (lstProducts.Any())
            {
                decimal totalPrice = prmotionService.GetTotalPrice(lstProducts);
                Console.WriteLine("Total Price is :"+ totalPrice);

            }
            else
            {
                Console.WriteLine("No Products Found");
            }
            Console.ReadLine();
        }
    }
}
