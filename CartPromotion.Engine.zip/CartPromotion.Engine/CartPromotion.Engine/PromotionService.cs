﻿using CartPromotion.Engine.Entities;
using System.Collections.Generic;
namespace CartPromotion.Engine
{
    public class PrmotionService:IProductPromotion
    {
        public decimal GetPriceByType(string type)
        {
            decimal price = 0;
            switch (type)
            {
                case "A":
                    price = 50m;

                    break;
                case "B":
                    price = 30m;

                    break;
                case "C":
                    price = 20m;

                    break;
                case "D":
                    price =  15m;
                    break;
            }
            return price;
        }

        public decimal GetTotalPrice(List<Product> products)
        {
            int counterOfA = 0;
            decimal priceOfA = 50;
            int counterOfB = 0;
            decimal priceOfB = 30;
            int counterOfC = 0;
            decimal priceOfC = 20;
            int counterOfD = 0;
            decimal priceOfD = 15;         
                  
            foreach (Product product in products)
            {
                switch (product.Type)
                {
                    case "A":
                      counterOfA += 1;
                        break;
                    case "B":
                     counterOfB += 1;
                        break;
                    case "C":
                     counterOfC += 1;
                        break;
                    case "D":
                     counterOfD += 1;
                        break;
                }
            }
            decimal totalPriceOfA = (counterOfA / 3) * 130 + (counterOfA % 3 * priceOfA);
            decimal totalPriceOfB = (counterOfB / 2) * 45 + (counterOfB % 2 * priceOfB);
            decimal totalPriceOfC = (counterOfC * priceOfC);
            decimal totalPriceOfD = (counterOfD * priceOfD);
            return totalPriceOfA + totalPriceOfB + totalPriceOfC + totalPriceOfD;
        }
    }
}
